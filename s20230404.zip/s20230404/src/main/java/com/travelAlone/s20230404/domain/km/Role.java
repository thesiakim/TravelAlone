package com.travelAlone.s20230404.domain.km;


/**
 * 2023-04-14 조경민
 * 설명 : 관리자 권한 Enum
 * */
public enum Role {

    // User Admin, User
    rol100, rol200, rol300
}

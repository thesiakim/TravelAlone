package com.travelAlone.s20230404.model;

import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class CommonCode {
	//공통코드
	private String code;
	//공통코드명
	private String value;
}
